import React from 'react'

const Signup = (props) => {
  return (
    <div className="signup">
      <h1>Signup</h1>
      <h2>TODO: NEED BILLING COMP</h2>
    </div>
  )
}

export default Signup
