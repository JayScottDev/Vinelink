import React from 'react'

const Billing = (props) => {
  return (
    <div className="billing">
      <h1>Billing</h1>
      <h2>TODO: NEED BILLING COMP</h2>
    </div>
  )
}

export default Billing
