import React from 'react'

const Export = (props) => {
  return (
    <h1>DATA EXPORT!!</h1>
  )
}

export default Export
