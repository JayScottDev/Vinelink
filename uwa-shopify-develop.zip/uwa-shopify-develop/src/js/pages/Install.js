import React from 'react'

const Install = (props) => {
  return (
    <h1>Install</h1>
  )
}

export default Install
