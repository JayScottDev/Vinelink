import React from 'react'

const Faq = (props) => {
  return (
    <div className="faq">
      <h1>FAQ</h1>
      <h2>TODO: NEED COMPS AND CONTENT FOR FAQ</h2>
    </div>
  )
}

export default Faq
