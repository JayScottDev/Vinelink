ShopifyApp.ready(function () {
  ShopifyApp.Bar.initialize({
    title: 'Compliancy Connector',
  });
  //kosta put yo shit here

});

$(() => {
})

//if you're down here you're doing it wrong

/*
  $.ajax({
    method: '' //GET or POST,
    url: '',
    data: {} //if POST
  }).then(function(data) {
    //do something with data
  }).catch(function(err) {
    //shit went wrong!
    throw err;
  })

*/
